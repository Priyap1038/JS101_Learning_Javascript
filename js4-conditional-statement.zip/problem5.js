let x=32/0;
console.log(x);