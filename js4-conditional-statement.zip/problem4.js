let username="Priya P";
let password="Priya@123";

let input_username= "Priya P";
let input_password="Priya@123";

if(username!==input_username || password!==input_password)
{
  console.log("Please check the username and password");
}
else 
{
  console.log("Login successful");
}