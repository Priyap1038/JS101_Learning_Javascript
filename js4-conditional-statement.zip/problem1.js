let number=10;
if(number%3==0)
{
  console.log("multiple of 3");
}
else
{
  console.log("Not a multiple of 3");
}