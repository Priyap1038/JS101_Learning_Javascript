let age=21;
if(age>18)
{
  console.log("Apply for a license");
}
else
{
  console.log("NA");
}