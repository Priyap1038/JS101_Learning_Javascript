let a=10;
let b=16;
if(a>b)
{
  console.log("a is greater");
}
else if(a===b)
{
  console.log("both equal");
}
else
{
  console.log("b is greater");
}