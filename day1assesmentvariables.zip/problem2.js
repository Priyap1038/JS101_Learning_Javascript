let name="Priya P";
console.log(name);

let fatherName="Ravi";
console.log(fatherName);

let MotherName="Shobha";
console.log(MotherName);