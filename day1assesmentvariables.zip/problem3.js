let name="Priya P";
let age=23;
console.log(name);
console.log(age);
